-Permet de calculer des fonctions f (sauf fonction sqrt;e... pour l'instant)
  - Possibilité de définir l'intervalle de la fonction

A faire:
  
  -A rajouter (très important): 
    - Calcul des racines du polynome
   - Calcul des extremums locaux
    - Possibilité de calculer la valeur de f(x) pour une valeur de x que l'on donne

  -A rajouter (possiblement): 
    - Calcul de la position de la souris selon l'axe des x, puis donné la valeur de f(x) et y mettre un point -> Donne un point mobile quand on bouge la souris
   - Calcul de la dérivé
   - Calcul de la tangente + affichage
    - ((((((((((Calcul de intégrales))))))))))
  
